import pandas as pd
import tkinter as tk
from tkinter import filedialog
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.ensemble import GradientBoostingRegressor
import lightgbm as lgb
import xgboost as xgb
import matplotlib.pyplot as plt
import os
import time
import shap
import numpy as np
import seaborn as sns

root = tk.Tk()
root.withdraw()
csv_path = filedialog.askopenfilename(title = "Select CSV file",
                                      filetypes = (("CSV files", "*.csv"),("All files", "*.*")))

Setting_File_path = filedialog.askopenfilename(title = "Select Excel file",
                                      filetypes = (("Excel files", "*.xlsx"),("All files", "*.*")))

print(csv_path)
print(Setting_File_path)

# Read Setting File
df_setting = pd.read_excel(Setting_File_path)

analysis_list = df_setting.loc[df_setting['Analysis_List'].notna(), 'Analysis_List'].tolist()
target_variable = df_setting.loc[df_setting['Target_Variable'].notna(), 'Target_Variable'].values[0]
num_features = int(df_setting.loc[df_setting['Surviving_Feature'].notna(), 'Surviving_Feature'].values[0])


# Read & Select data
data = pd.read_csv(csv_path)

#features,X and target,y #.drop(columns=[target_variable])
X = data[analysis_list]
y = data[target_variable]
Xall=X

# Plot function
def save_plot(plot, filename):
    plot.savefig(filename, bbox_inches='tight')
    plt.close()

start_time = time.time()

# Scatter matrix
sns.pairplot(data, diag_kind='kde')
plt.title('Scatter matrix of the Data')
pairplot_file_path = os.path.join(os.path.dirname(csv_path), "scatter matrix.png")
save_plot(plt, pairplot_file_path)

# Correlation Heatmap
corr = data.corr()
sns.heatmap(corr, annot=True, cmap='coolwarm', cbar=True)
plt.title('Correlation Heatmap of the Data')
heatmap_file_path = os.path.join(os.path.dirname(csv_path), "correlation_heatmap.png")
save_plot(plt, heatmap_file_path)


# Recursive Feature Elimination
while X.shape[1] > num_features-1:
    # Random Forest
    rf = RandomForestRegressor(n_estimators=100, random_state=0)
    rf.fit(X, y)
    importances_rf = rf.feature_importances_

    # Permutation
    result = permutation_importance(rf, X, y, n_repeats=10, random_state=0)
    importances_permutation = result.importances_mean

    #GBR
    gb = GradientBoostingRegressor(random_state=0)
    gb.fit(X, y)
    importances_gb = gb.feature_importances_

    #XGBoost model
    xg = xgb.XGBRegressor(random_state=0)
    xg.fit(X, y)
    importances_xg = xg.feature_importances_

    #DataFrame
    importances_df = pd.DataFrame({
        'Feature': X.columns,
        'Importance_RF': importances_rf,
        'Importance_Permutation': importances_permutation,
        'Importance_GB': importances_gb,
        'Importance_XG': importances_xg
    })

    # Normalization
    importances_df['Importance_RF'] = importances_df['Importance_RF'] / importances_df['Importance_RF'].sum()
    importances_df['Importance_Permutation'] = importances_df['Importance_Permutation'] / importances_df['Importance_Permutation'].sum()
    importances_df['Importance_GB'] = importances_df['Importance_GB'] / importances_df['Importance_GB'].sum()
    importances_df['Importance_XG'] = importances_df['Importance_XG'] / importances_df['Importance_XG'].sum()

    #mean importance
    importances_df['Mean_Importance'] = importances_df[['Importance_RF', 'Importance_Permutation', 'Importance_GB', 'Importance_XG']].mean(axis=1)

    #Sort
    importances_df = importances_df.sort_values(by='Mean_Importance', ascending=False)

    # Plot
    ax = importances_df.plot(x='Feature', y=['Importance_RF', 'Importance_Permutation', 'Importance_GB', 'Importance_XG', 'Mean_Importance'], kind='bar', figsize=(12, 6))
    plt.title('Feature Importances')
    plt.ylabel('Importance')

    # Rotate x-axis names
    plt.xticks(rotation=45, ha='right')

    # Save plot to file
    plot_file_path = os.path.join(os.path.dirname(csv_path), f"importances_{X.shape[1]}_features.png")
    plt.savefig(plot_file_path, bbox_inches='tight')
    plt.close()

    if X.shape[1] == num_features:
        Xlast=X

    # Drop least important feature
    X = X.drop(columns=[importances_df.iloc[-1]['Feature']])

print("RFE completed.")


# Calculate SHAP
xg_final = xgb.XGBRegressor(n_estimators=100, random_state=0)
xg_final.fit(Xall, y)

explainer = shap.Explainer(xg_final)
shap_values = explainer(Xall)


# Summary plot (bar)
shap.plots.bar(shap_values, show=False)
plot_file_path = os.path.join(os.path.dirname(csv_path), f"shap_{Xall.shape[1]}_summary-bar.png")
save_plot(plt, plot_file_path)


# Summary plot (beeswarm)
shap.summary_plot(shap_values.values, Xall, show=False)
plot_file_path = os.path.join(os.path.dirname(csv_path), f"shap_{Xall.shape[1]}_summary-beeswarm.png")
save_plot(plt, plot_file_path)


# Summary plot (interaction)
shap_interaction_values = explainer.shap_interaction_values(Xall)
shap.summary_plot(shap_interaction_values, Xall, show=False)
plot_file_path = os.path.join(os.path.dirname(csv_path), f"shap_{Xall.shape[1]}_summary-interaction.png")
save_plot(plt, plot_file_path)


# Identify feature:1st, 2nd, 3rd highest SHAP
shap_sum = np.abs(shap_values.values).mean(axis=0)
indices = np.argsort(shap_sum)
ind = Xall.columns[indices[-1]]  # feature:highest SHAP
interaction_index1 = Xall.columns[indices[-2]]  # feature:2nd highest SHAP
interaction_index2 = Xall.columns[indices[-3]]  # feature:3rd highest SHAP

# Dependence plot with 1st and 2nd features
shap.dependence_plot(ind, shap_values.values, Xall, interaction_index=interaction_index1, show=False)
plot_file_path = os.path.join(os.path.dirname(csv_path), f"shap_{Xall.shape[1]}_dependence_1st_2nd.png")
save_plot(plt, plot_file_path)

# Dependence plot with 1st and 3rd features
shap.dependence_plot(ind, shap_values.values, Xall, interaction_index=interaction_index2, show=False)
plot_file_path = os.path.join(os.path.dirname(csv_path), f"shap_{Xall.shape[1]}_dependence_1st_3rd.png")
save_plot(plt, plot_file_path)


# force plot All
# shap.force_plot(explainer.expected_value, shap_values.values, Xall)

end_time = time.time()
print("SHAP completed. Run time ", end_time - start_time, "sec")
