import os
import sys
import pprint
pprint.pprint(sys.path)

sys.path.append(os.path.join(os.path.dirname(__file__), r'c:\users\j0114690\appdata\local\anaconda3\envs\myenv\lib\site-packages'))

import pandas as pd
#from pandas_profiling import ProfileReport
import sweetviz as sv
from autoviz.AutoViz_Class import AutoViz_Class
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()
csv_path = filedialog.askopenfilename(title = "Select CSV file",
                                      filetypes = (("CSV files", "*.csv"),("All files", "*.*")))

df = pd.read_csv(csv_path)

try:
    # pandas-profilingのレポートを作成
    profile = ProfileReport(df, title="Pandas Profiling Report")
    profile.to_file("report.html")

    # Sweetvizのレポートを生成
    sweet_report = sv.analyze(df)
    sweet_report.show_html('sautovizweetviz_report.html')

    # AutoVizのレポートを生成
    AV = AutoViz_Class()
    autoviz_report = AV.AutoViz(csv_path)
except Exception as e:
    print(f"An error occurred: {e}")
