import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import tkinter as tk
from tkinter import filedialog
import os

root = tk.Tk()
root.withdraw()

csv_path = filedialog.askopenfilename(title = "Select Excel file",
                                        filetypes = (("Excel files", "*.csv"),("All files", "*.*")))

# CSVファイルの読み込み
df = pd.read_csv(csv_path)

# 正規化する列の選択（ここでは全ての列を選択）
columns_to_scale = df.columns

# MinMaxScalerのインスタンス化
scaler = MinMaxScaler()

# 正規化の実行
df[columns_to_scale] = scaler.fit_transform(df[columns_to_scale])

# 出力ファイルパスの生成
output_path = os.path.join(os.path.dirname(csv_path),
                           os.path.splitext(os.path.basename(csv_path))[0] + '_normalized.csv')

# 結果を新たなCSVファイルとしてエクスポート
df.to_csv(output_path, index=False)
